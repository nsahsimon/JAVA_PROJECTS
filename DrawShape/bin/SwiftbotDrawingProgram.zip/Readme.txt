// open the terminal in this directory and run the following commands

1. Compile the java code
javac SwiftbotDrawingProgram.java

2. Run the java code
java SwiftbotDrawingProgram